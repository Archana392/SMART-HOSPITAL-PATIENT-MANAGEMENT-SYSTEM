import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Avatar,
  Badge,
  Box,
  TextField,
  InputAdornment,
  Chip,
} from "@mui/material";

import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";
import NotificationsRoundedIcon from "@mui/icons-material/NotificationsRounded";
import CalendarMonthRoundedIcon from "@mui/icons-material/CalendarMonthRounded";
import AccessTimeRoundedIcon from "@mui/icons-material/AccessTimeRounded";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";
import FullscreenRoundedIcon from "@mui/icons-material/FullscreenRounded";

export default function Navbar({
  drawerWidth,
  handleDrawerToggle,
}) {
  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const time = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <AppBar
      position="fixed"
      elevation={0}
      sx={{
        width: {
          lg: `calc(100% - ${drawerWidth}px)`,
        },
        ml: {
          lg: `${drawerWidth}px`,
        },

        bgcolor: "rgba(255,255,255,.82)",
        backdropFilter: "blur(18px)",
        borderBottom: "1px solid #E8EEF5",
      }}
    >
      <Toolbar
        sx={{
          justifyContent: "space-between",
          py: 1,
        }}
      >
        {/* LEFT */}

        <Box
          display="flex"
          alignItems="center"
          gap={2}
        >
          <IconButton
            onClick={handleDrawerToggle}
            sx={{
              display: {
                lg: "none",
              },
            }}
          >
            <MenuRoundedIcon />
          </IconButton>

          <Box>
            <Typography
              variant="h4"
              fontWeight={700}
              color="#1F2937"
            >
              Dashboard
            </Typography>

            <Typography
              color="text.secondary"
              fontSize={15}
            >
              Welcome back, Administrator 👋
            </Typography>
          </Box>
        </Box>

        {/* SEARCH */}

        <TextField
          placeholder="Search workers, doctors, hospitals..."
          size="small"
          sx={{
            width: 420,

            display: {
              xs: "none",
              md: "block",
            },

            "& .MuiOutlinedInput-root": {
              bgcolor: "#F8FAFC",
              borderRadius: 4,
            },
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchRoundedIcon />
              </InputAdornment>
            ),
          }}
        />

        {/* RIGHT */}

        <Box
          display="flex"
          alignItems="center"
          gap={2}
        >
          <Chip
            icon={<CalendarMonthRoundedIcon />}
            label={today}
            sx={{
              display: {
                xs: "none",
                md: "flex",
              },
            }}
          />

          <Chip
            icon={<AccessTimeRoundedIcon />}
            label={time}
            color="primary"
            variant="outlined"
            sx={{
              display: {
                xs: "none",
                lg: "flex",
              },
            }}
          />

          <IconButton>
            <FullscreenRoundedIcon />
          </IconButton>

          <IconButton>
            <Badge
              badgeContent={6}
              color="error"
            >
              <NotificationsRoundedIcon />
            </Badge>
          </IconButton>

          <Box
            display="flex"
            alignItems="center"
            gap={1.5}
            sx={{
              bgcolor: "#F8FAFC",
              px: 1.5,
              py: .8,
              borderRadius: 4,
            }}
          >
            <Avatar
              src="/doctor.png"
              sx={{
                width: 44,
                height: 44,
                bgcolor: "#1565C0",
              }}
            >
              A
            </Avatar>

            <Box
              sx={{
                display: {
                  xs: "none",
                  md: "block",
                },
              }}
            >
              <Typography
                fontWeight={700}
                fontSize={14}
              >
                Admin User
              </Typography>

              <Typography
                variant="caption"
                color="text.secondary"
              >
                System Administrator
              </Typography>
            </Box>

            <KeyboardArrowDownRoundedIcon />
          </Box>
        </Box>
      </Toolbar>
    </AppBar>
  );
}