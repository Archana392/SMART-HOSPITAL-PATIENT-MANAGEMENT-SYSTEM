import {
  Avatar,
  Box,
  Button,
  Chip,
  Divider,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

import SmartToyRoundedIcon from "@mui/icons-material/SmartToyRounded";
import SendRoundedIcon from "@mui/icons-material/SendRounded";
import PsychologyRoundedIcon from "@mui/icons-material/PsychologyRounded";
import AutoAwesomeRoundedIcon from "@mui/icons-material/AutoAwesomeRounded";

const suggestions = [
  "Show diabetic workers",
  "Pending vaccinations",
  "Emergency cases",
  "Generate health report",
];

export default function AIAssistant() {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 5,
        height: "100%",
        boxShadow: "0 12px 30px rgba(0,0,0,.06)",
      }}
    >
      <Stack
        direction="row"
        spacing={2}
        alignItems="center"
      >
        <Avatar
          sx={{
            bgcolor: "#1976D2",
            width: 55,
            height: 55,
          }}
        >
          <SmartToyRoundedIcon />
        </Avatar>

        <Box>
          <Typography
            variant="h6"
            fontWeight={700}
          >
            AI Health Assistant
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
          >
            Ask anything about workers, hospitals or records
          </Typography>
        </Box>
      </Stack>

      <Divider sx={{ my: 3 }} />

      <Paper
        elevation={0}
        sx={{
          p: 2,
          borderRadius: 3,
          bgcolor: "#F3F8FD",
        }}
      >
        <Typography
          fontWeight={600}
          gutterBottom
        >
          🤖 AI Response
        </Typography>

        <Typography
          variant="body2"
          color="text.secondary"
          lineHeight={1.8}
        >
          Hello Administrator 👋

          <br />
          <br />

          I can help you analyze worker health,
          identify high-risk patients,
          generate reports,
          check vaccination status,
          and summarize medical records.
        </Typography>
      </Paper>

      <Typography
        mt={3}
        mb={2}
        fontWeight={700}
      >
        Suggested Questions
      </Typography>

      <Stack
        direction="row"
        spacing={1}
        useFlexGap
        flexWrap="wrap"
      >
        {suggestions.map((item) => (
          <Chip
            key={item}
            label={item}
            icon={<AutoAwesomeRoundedIcon />}
            clickable
            sx={{
              mb: 1,
              borderRadius: 3,
            }}
          />
        ))}
      </Stack>

      <Box mt={3}>
        <TextField
          fullWidth
          placeholder="Ask AI Assistant..."
          multiline
          rows={2}
        />
      </Box>

      <Button
        fullWidth
        variant="contained"
        startIcon={<PsychologyRoundedIcon />}
        endIcon={<SendRoundedIcon />}
        sx={{
          mt: 3,
          py: 1.5,
          borderRadius: 3,
          textTransform: "none",
          fontWeight: 600,
        }}
      >
        Ask AI
      </Button>
    </Paper>
  );
}