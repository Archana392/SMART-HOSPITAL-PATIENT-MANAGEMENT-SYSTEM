import { Box, Paper, Typography } from "@mui/material";

import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";

const workerData = [
  { month: "Jan", workers: 20 },
  { month: "Feb", workers: 35 },
  { month: "Mar", workers: 48 },
  { month: "Apr", workers: 72 },
  { month: "May", workers: 95 },
  { month: "Jun", workers: 130 },
];

const genderData = [
  { name: "Male", value: 65 },
  { name: "Female", value: 35 },
];

const bloodData = [
  { group: "A+", value: 18 },
  { group: "B+", value: 28 },
  { group: "AB+", value: 12 },
  { group: "O+", value: 42 },
  { group: "A-", value: 8 },
  { group: "B-", value: 5 },
  { group: "AB-", value: 3 },
  { group: "O-", value: 9 },
];

const COLORS = [
  "#1565C0",
  "#43A047",
];

export default function Charts() {
  return (
    <Box sx={{ mt: 4 }}>

      {/* Top Charts */}

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "2fr 1fr",
          },
          gap: 3,
        }}
      >

        {/* Line Chart */}

        <Paper
          elevation={3}
          sx={{
            p: 3,
            borderRadius: 4,
            height: 420,
          }}
        >
          <Typography
            variant="h6"
            fontWeight={700}
            mb={2}
          >
            Monthly Worker Registration
          </Typography>

          <ResponsiveContainer
            width="100%"
            height={320}
          >
            <LineChart data={workerData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />

              <Line
                type="monotone"
                dataKey="workers"
                stroke="#1565C0"
                strokeWidth={4}
              />
            </LineChart>
          </ResponsiveContainer>
        </Paper>

        {/* Pie Chart */}

        <Paper
          elevation={3}
          sx={{
            p: 3,
            borderRadius: 4,
            height: 420,
          }}
        >
          <Typography
            variant="h6"
            fontWeight={700}
            mb={2}
          >
            Gender Distribution
          </Typography>

          <ResponsiveContainer
            width="100%"
            height={320}
          >
            <PieChart>
              <Pie
                data={genderData}
                dataKey="value"
                nameKey="name"
                outerRadius={110}
                label
              >
                {genderData.map((item, index) => (
                  <Cell
                    key={index}
                    fill={COLORS[index]}
                  />
                ))}
              </Pie>

              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Paper>

      </Box>

      {/* Bottom Chart */}

      <Paper
        elevation={3}
        sx={{
          mt: 3,
          p: 3,
          borderRadius: 4,
        }}
      >
        <Typography
          variant="h6"
          fontWeight={700}
          mb={2}
        >
          Blood Group Distribution
        </Typography>

        <ResponsiveContainer
          width="100%"
          height={320}
        >
          <BarChart data={bloodData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="group" />
            <YAxis />
            <Tooltip />

            <Bar
              dataKey="value"
              fill="#1565C0"
              radius={[8, 8, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </Paper>

    </Box>
  );
}