import {
  Paper,
  Typography,
  Box,
  Chip,
  Avatar,
  Stack,
} from "@mui/material";

import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";
import VaccinesRoundedIcon from "@mui/icons-material/VaccinesRounded";
import MedicalServicesRoundedIcon from "@mui/icons-material/MedicalServicesRounded";
import GroupsRoundedIcon from "@mui/icons-material/GroupsRounded";

const alerts = [
  {
    title: "Emergency Cases",
    subtitle: "3 Workers require immediate attention",
    icon: <WarningAmberRoundedIcon />,
    color: "#E53935",
    status: "Critical",
  },
  {
    title: "Vaccination Due",
    subtitle: "18 Workers pending vaccination",
    icon: <VaccinesRoundedIcon />,
    color: "#FB8C00",
    status: "Pending",
  },
  {
    title: "Doctors Available",
    subtitle: "68 Doctors currently active",
    icon: <MedicalServicesRoundedIcon />,
    color: "#43A047",
    status: "Available",
  },
  {
    title: "Today's Registration",
    subtitle: "12 New migrant workers added",
    icon: <GroupsRoundedIcon />,
    color: "#1976D2",
    status: "Updated",
  },
];

export default function EmergencyAlerts() {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 5,
        boxShadow: "0 10px 30px rgba(0,0,0,.06)",
        height: "100%",
      }}
    >
      <Typography
        variant="h6"
        fontWeight="bold"
        mb={3}
      >
        🚨 Emergency Alerts
      </Typography>

      <Stack spacing={2.5}>
        {alerts.map((item, index) => (
          <Box
            key={index}
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              p: 2,
              borderRadius: 3,
              bgcolor: "#F8FAFC",
              transition: ".3s",

              "&:hover": {
                transform: "translateX(5px)",
                boxShadow: "0 8px 20px rgba(0,0,0,.08)",
              },
            }}
          >
            <Box
              display="flex"
              alignItems="center"
              gap={2}
            >
              <Avatar
                sx={{
                  bgcolor: item.color,
                  width: 52,
                  height: 52,
                }}
              >
                {item.icon}
              </Avatar>

              <Box>
                <Typography fontWeight={700}>
                  {item.title}
                </Typography>

                <Typography
                  variant="body2"
                  color="text.secondary"
                >
                  {item.subtitle}
                </Typography>
              </Box>
            </Box>

            <Chip
              label={item.status}
              sx={{
                bgcolor: item.color,
                color: "#fff",
                fontWeight: 600,
              }}
            />
          </Box>
        ))}
      </Stack>
    </Paper>
  );
}
