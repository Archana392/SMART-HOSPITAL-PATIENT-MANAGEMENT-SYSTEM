import {
  Box,
  Typography,
  Button,
  Stack,
  Paper,
  Chip,
} from "@mui/material";

import {
  ArrowForwardRounded,
  PersonAddAlt1Rounded,
  FolderSharedRounded,
  FavoriteRounded,
  LocalHospitalRounded,
  VaccinesRounded,
  QrCode2Rounded,
} from "@mui/icons-material";

import { motion } from "framer-motion";

export default function Hero() {
  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <Paper
      component={motion.div}
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      elevation={0}
      sx={{
        borderRadius: 6,
        overflow: "hidden",
        position: "relative",
        minHeight: 560,
        backgroundImage: `
          linear-gradient(
            rgba(6,37,84,.78),
            rgba(6,37,84,.78)
          ),
          url("/hero-bg.jpg")
        `,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <Box
        sx={{
          p: {
            xs: 3,
            md: 6,
          },
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "1.2fr .8fr",
          },
          alignItems: "center",
          gap: 5,
        }}
      >
        {/* LEFT */}

        <Box>

          <Chip
            label="🇮🇳 Government of India • Ministry of Health & Family Welfare"
            sx={{
              bgcolor: "#00C853",
              color: "#fff",
              fontWeight: 700,
              mb: 3,
              px: 1,
            }}
          />

          <Typography
            sx={{
              color: "#fff",
              fontWeight: 800,
              textShadow: "0 4px 18px rgba(0,0,0,.35)",
              fontSize: {
                xs: 36,
                md: 56,
              },
              lineHeight: 1.15,
            }}
          >
            National Health
            <br />
            Command Center
          </Typography>

          <Typography
            sx={{
              mt: 2,
              color: "#BBDEFB",
              fontSize: {
                xs: 20,
                md: 24,
              },
              fontWeight: 500,
            }}
          >
            Digital Health Record Management
            <br />
            System for Migrant Workers
          </Typography>

          <Typography
            sx={{
              color: "#E3F2FD",
              mt: 3,
              fontSize: 18,
              lineHeight: 1.9,
              maxWidth: 650,
            }}
          >
            A centralized healthcare platform enabling secure digital
            health records, portable medical history, AI-powered
            healthcare analytics, emergency support, vaccination
            tracking, QR-based health identification and nationwide
            hospital connectivity.
          </Typography>

          <Stack
            direction="row"
            spacing={2}
            mt={5}
            flexWrap="wrap"
            useFlexGap
          >
            <Button
              variant="contained"
              size="large"
              startIcon={<PersonAddAlt1Rounded />}
              endIcon={<ArrowForwardRounded />}
              sx={{
                bgcolor: "#fff",
                color: "#1565C0",
                px: 4,
                py: 1.6,
                borderRadius: 4,
                fontWeight: 700,
                transition: ".3s",
                "&:hover": {
                  bgcolor: "#F3F8FD",
                  transform: "translateY(-3px)",
                },
              }}
            >
              Register Worker
            </Button>

            <Button
              variant="contained"
              size="large"
              startIcon={<QrCode2Rounded />}
              sx={{
                bgcolor: "#00C853",
                color: "#fff",
                px: 4,
                py: 1.6,
                borderRadius: 4,
                fontWeight: 700,
                transition: ".3s",
                "&:hover": {
                  bgcolor: "#00B248",
                  transform: "translateY(-3px)",
                },
              }}
            >
              Scan Health QR
            </Button>

            <Button
              variant="outlined"
              size="large"
              startIcon={<FolderSharedRounded />}
              sx={{
                color: "#fff",
                borderColor: "#fff",
                px: 4,
                py: 1.6,
                borderRadius: 4,
                transition: ".3s",
                "&:hover": {
                  borderColor: "#fff",
                  bgcolor: "#ffffff18",
                  transform: "translateY(-3px)",
                },
              }}
            >
              Medical Records
            </Button>
          </Stack>

          <Stack
            direction="row"
            spacing={2}
            mt={5}
            flexWrap="wrap"
            useFlexGap
          >
            <Chip
              icon={<FavoriteRounded />}
              label="👷 1250 Workers"
              sx={{
                bgcolor: "#ffffff18",
                color: "#fff",
                height: 42,
                borderRadius: 20,
                fontWeight: 700,
              }}
            />

            <Chip
              icon={<LocalHospitalRounded />}
              label="🏥 15 Hospitals"
              sx={{
                bgcolor: "#ffffff18",
                color: "#fff",
                height: 42,
                borderRadius: 20,
                fontWeight: 700,
              }}
            />

            <Chip
              icon={<VaccinesRounded />}
              label="💉 850 Vaccinations"
              sx={{
                bgcolor: "#ffffff18",
                color: "#fff",
                height: 42,
                borderRadius: 20,
                fontWeight: 700,
              }}
            />
                      </Stack>

        </Box>

        {/* RIGHT */}

        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          sx={{
            position: "relative",
          }}
        >
          <Box
            component="img"
            src="/doctor.png"
            alt="Doctor"

            sx={{
              width: {
                xs: 300,
                md: 520,
              },

              zIndex: 2,

              filter:
                "drop-shadow(0 30px 50px rgba(0,0,0,.35))",

              animation: "float 4s ease-in-out infinite",

              "@keyframes float": {
                "0%": {
                  transform: "translateY(0px)",
                },
                "50%": {
                  transform: "translateY(-12px)",
                },
                "100%": {
                  transform: "translateY(0px)",
                },
              },
            }}
          />
        </Box>

      </Box>

      {/* Floating Glass Card */}

      <Paper
        elevation={0}
        sx={{
          position: "absolute",
          bottom: 25,
          right: 25,

          boxShadow: "0 20px 60px rgba(0,0,0,.30)",

          px: 3,
          py: 2.5,

          borderRadius: 5,

          bgcolor: "rgba(255,255,255,.15)",

          backdropFilter: "blur(16px)",

          border: "1px solid rgba(255,255,255,.18)",

          color: "#fff",

          width: 280,

          display: {
            xs: "none",
            md: "block",
          },
        }}
      >
        <Typography
          fontWeight={700}
          fontSize={20}
        >
          National Healthcare Status
        </Typography>

        <Typography mt={2}>
          🟢 System Status : Online
        </Typography>

        <Typography>
          📅 {today}
        </Typography>

        <Typography>
          👨‍⚕️ Doctors Available : 68
        </Typography>

        <Typography>
          🏥 Partner Hospitals : 15
        </Typography>

        <Typography>
          🚑 Emergency Cases : 3
        </Typography>

        <Typography>
          💉 Vaccinations Today : 18
        </Typography>

        <Typography>
          ❤️ Health Index : 92%
        </Typography>
      </Paper>

      {/* Bottom Fade */}

      <Box
        sx={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,

          height: 90,

          background:
            "linear-gradient(to top,#F5F9FF,transparent)",
        }}
      />

    </Paper>
  );
}