import {
  Paper,
  Typography,
  List,
  ListItem,
  ListItemAvatar,
  Avatar,
  ListItemText,
} from "@mui/material";

import PersonIcon from "@mui/icons-material/Person";
import VaccinesRoundedIcon from "@mui/icons-material/VaccinesRounded";
import MedicalServicesRoundedIcon from "@mui/icons-material/MedicalServicesRounded";

const data = [
  {
    icon: <PersonIcon />,
    title: "New Worker Registered",
    sub: "10 minutes ago",
  },
  {
    icon: <VaccinesRoundedIcon />,
    title: "Vaccination Completed",
    sub: "35 minutes ago",
  },
  {
    icon: <MedicalServicesRoundedIcon />,
    title: "Doctor Assigned",
    sub: "1 hour ago",
  },
];

export default function RecentActivity() {
  return (
    <Paper
      sx={{
        mt: 5,
        p: 4,
        borderRadius: 5,
      }}
    >
      <Typography
        variant="h5"
        fontWeight={700}
        mb={2}
      >
        Recent Activity
      </Typography>

      <List>
        {data.map((item) => (
          <ListItem key={item.title}>
            <ListItemAvatar>
              <Avatar>{item.icon}</Avatar>
            </ListItemAvatar>

            <ListItemText
              primary={item.title}
              secondary={item.sub}
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  );
}