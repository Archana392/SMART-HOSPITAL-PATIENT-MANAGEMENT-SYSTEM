import {
  Avatar,
  Box,
  Chip,
  LinearProgress,
  Paper,
  Stack,
  Typography,
} from "@mui/material";

import VaccinesRoundedIcon from "@mui/icons-material/VaccinesRounded";
import CalendarMonthRoundedIcon from "@mui/icons-material/CalendarMonthRounded";
import LocalHospitalRoundedIcon from "@mui/icons-material/LocalHospitalRounded";

const vaccines = [
  {
    name: "Ramesh Kumar",
    vaccine: "COVID-19 Booster",
    hospital: "Apollo Hospital",
    due: "Today",
    progress: 100,
    status: "Completed",
    color: "#43A047",
  },
  {
    name: "Priya Devi",
    vaccine: "Hepatitis B",
    hospital: "AIIMS Delhi",
    due: "Tomorrow",
    progress: 70,
    status: "Pending",
    color: "#FB8C00",
  },
  {
    name: "Rahul Singh",
    vaccine: "Influenza",
    hospital: "CMC Vellore",
    due: "25 Jun",
    progress: 40,
    status: "Scheduled",
    color: "#1976D2",
  },
  {
    name: "Suresh Patel",
    vaccine: "Tetanus",
    hospital: "Govt Hospital",
    due: "28 Jun",
    progress: 20,
    status: "Upcoming",
    color: "#8E24AA",
  },
];

export default function UpcomingVaccination() {
  return (
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 5,
        boxShadow: "0 10px 30px rgba(0,0,0,.06)",
        height: "100%",
      }}
    >
      <Typography
        variant="h6"
        fontWeight={700}
        mb={3}
      >
        💉 Upcoming Vaccinations
      </Typography>

      <Stack spacing={3}>
        {vaccines.map((item, index) => (
          <Box
            key={index}
            sx={{
              p: 2,
              borderRadius: 3,
              bgcolor: "#F8FAFC",
              transition: ".3s",

              "&:hover": {
                transform: "translateY(-3px)",
              },
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
            >
              <Stack
                direction="row"
                spacing={2}
                alignItems="center"
              >
                <Avatar
                  sx={{
                    bgcolor: item.color,
                  }}
                >
                  {item.name.charAt(0)}
                </Avatar>

                <Box>
                  <Typography fontWeight={700}>
                    {item.name}
                  </Typography>

                  <Typography
                    variant="body2"
                    color="text.secondary"
                  >
                    <VaccinesRoundedIcon
                      sx={{
                        fontSize: 16,
                        mr: .5,
                        verticalAlign: "middle",
                      }}
                    />
                    {item.vaccine}
                  </Typography>
                </Box>
              </Stack>

              <Chip
                label={item.status}
                sx={{
                  bgcolor: item.color,
                  color: "#fff",
                  fontWeight: 600,
                }}
              />
            </Stack>

            <Typography
              variant="body2"
              mt={2}
            >
              <LocalHospitalRoundedIcon
                sx={{
                  fontSize: 16,
                  mr: .5,
                  verticalAlign: "middle",
                  color: "#1976D2",
                }}
              />
              {item.hospital}
            </Typography>

            <Typography
              variant="body2"
              mt={1}
            >
              <CalendarMonthRoundedIcon
                sx={{
                  fontSize: 16,
                  mr: .5,
                  verticalAlign: "middle",
                  color: "#1976D2",
                }}
              />
              Due : {item.due}
            </Typography>

            <LinearProgress
              variant="determinate"
              value={item.progress}
              sx={{
                mt: 2,
                height: 10,
                borderRadius: 10,
              }}
            />
          </Box>
        ))}
      </Stack>
    </Paper>
  );
}