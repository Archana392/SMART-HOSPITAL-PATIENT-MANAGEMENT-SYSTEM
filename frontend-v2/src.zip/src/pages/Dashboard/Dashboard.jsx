import { Box, Typography, Paper, Chip } from "@mui/material";

import MainLayout from "../../layouts/MainLayout";

import Hero from "../../components/dashboard/Hero";
import Charts from "../../components/dashboard/Charts";
import QuickActions from "../../components/dashboard/QuickActions";
import RecentActivity from "../../components/dashboard/RecentActivity";
import EmergencyAlerts from "../../components/dashboard/EmergencyAlerts";
import UpcomingVaccination from "../../components/dashboard/UpcomingVaccination";
import AIAssistant from "../../components/dashboard/AIAssistant";
import QRCodeCard from "../../components/dashboard/QRCodeCard";
import HealthSummary from "../../components/dashboard/HealthSummary";

import CountUp from "react-countup";

import GroupsRoundedIcon from "@mui/icons-material/GroupsRounded";
import MedicalServicesRoundedIcon from "@mui/icons-material/MedicalServicesRounded";
import LocalHospitalRoundedIcon from "@mui/icons-material/LocalHospitalRounded";
import FolderSharedRoundedIcon from "@mui/icons-material/FolderSharedRounded";
import CircleRoundedIcon from "@mui/icons-material/CircleRounded";

const stats = [
  {
    title: "Registered Workers",
    value: 1250,
    color: "#1565C0",
    icon: <GroupsRoundedIcon sx={{ fontSize: 42 }} />,
    subtitle: "Across India",
  },
  {
    title: "Doctors",
    value: 68,
    color: "#43A047",
    icon: <MedicalServicesRoundedIcon sx={{ fontSize: 42 }} />,
    subtitle: "Available Today",
  },
  {
    title: "Hospitals",
    value: 15,
    color: "#8E24AA",
    icon: <LocalHospitalRoundedIcon sx={{ fontSize: 42 }} />,
    subtitle: "Partner Network",
  },
  {
    title: "Medical Records",
    value: 9824,
    color: "#EF6C00",
    icon: <FolderSharedRoundedIcon sx={{ fontSize: 42 }} />,
    subtitle: "Digitally Stored",
  },
];

const systemCards = [
  {
    title: "System Status",
    value: "ONLINE",
    color: "#43A047",
  },
  {
    title: "Today's Registrations",
    value: "12",
    color: "#1565C0",
  },
  {
    title: "Emergency Alerts",
    value: "3",
    color: "#E53935",
  },
  {
    title: "Last Sync",
    value: "Just Now",
    color: "#FB8C00",
  },
];

export default function Dashboard() {
  return (
    <MainLayout>

      {/* HERO */}

      <Hero />

      {/* ================= SYSTEM STATUS ================= */}

      <Box
        sx={{
          mt: 4,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2,1fr)",
            lg: "repeat(4,1fr)",
          },
          gap: 3,
        }}
      >
        {systemCards.map((item) => (
          <Paper
            key={item.title}
            elevation={0}
            sx={{
              p: 3,
              borderRadius: 5,
              boxShadow: "0 12px 30px rgba(0,0,0,.06)",
            }}
          >
            <Typography color="text.secondary">
              {item.title}
            </Typography>

            <Typography
              mt={1}
              fontSize={28}
              fontWeight={700}
              sx={{
                color: item.color,
              }}
            >
              {item.value}
            </Typography>
          </Paper>
        ))}
      </Box>

      {/* ================= KPI CARDS ================= */}

      <Box
        sx={{
          mt: 5,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "1fr 1fr",
            lg: "repeat(4,1fr)",
          },
          gap: 3,
        }}
      >
        {stats.map((item) => (
          <Paper
            key={item.title}
            elevation={0}
            sx={{
              p: 3,
              borderRadius: 5,
              transition: ".35s",
              boxShadow: "0 12px 35px rgba(0,0,0,.06)",

              "&:hover": {
                transform: "translateY(-8px)",
              },
            }}
          >
            <Box
              display="flex"
              justifyContent="space-between"
            >
              <Box>

                <Typography
                  color="text.secondary"
                >
                  {item.title}
                </Typography>

                <Typography
                  mt={1}
                  fontWeight={700}
                  fontSize={34}
                >
                  <CountUp
                    end={item.value}
                    duration={2}
                    separator=","
                  />
                </Typography>

                <Chip
                  size="small"
                  icon={
                    <CircleRoundedIcon
                      sx={{
                        color: "#43A047 !important",
                        fontSize: 12,
                      }}
                    />
                  }
                  label="12% Growth"
                  sx={{
                    mt: 1,
                    bgcolor: "#E8F5E9",
                  }}
                />

                <Typography
                  mt={1}
                  color="text.secondary"
                  variant="body2"
                >
                  {item.subtitle}
                </Typography>

              </Box>

              <Box
                sx={{
                  width: 70,
                  height: 70,
                  bgcolor: item.color + "15",
                  borderRadius: "50%",
                  color: item.color,

                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {item.icon}
              </Box>
            </Box>
          </Paper>
        ))}
      </Box>

      {/* ================= ANALYTICS ================= */}

      <Box mt={6} mb={3}>
        <Typography
          variant="h4"
          fontWeight={700}
        >
          🇮🇳 National Health Command Center
        </Typography>

        <Typography
          color="text.secondary"
          mt={1}
        >
          Monitor migrant workers, partner hospitals,
          emergency alerts, vaccination coverage,
          and digital health records in real time.
        </Typography>
      </Box>

      <Charts />

      {/* ================= AI + ALERTS ================= */}

      <Box
        sx={{
          mt: 5,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "1fr 1fr",
          },
          gap: 3,
        }}
      >
        <AIAssistant />

        <EmergencyAlerts />
      </Box>

      {/* ================= QR + VACCINATION ================= */}

      <Box
        sx={{
          mt: 5,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "1fr 1fr",
          },
          gap: 3,
        }}
      >
        <QRCodeCard />

        <UpcomingVaccination />
      </Box>

      {/* ================= ACTIVITY ================= */}

      <Box
        sx={{
          mt: 5,
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            lg: "1fr 1fr",
          },
          gap: 3,
        }}
      >
        <RecentActivity />

        <QuickActions />
      </Box>

      {/* ================= HEALTH ================= */}

      <Box mt={5}>
        <HealthSummary />
      </Box>

      {/* ================= FOOTER ================= */}

      <Paper
        elevation={0}
        sx={{
          mt: 6,
          p: 3,
          borderRadius: 5,
          textAlign: "center",
          bgcolor: "#F8FAFC",
        }}
      >
        <Typography
          fontWeight={700}
        >
          Digital Health Record Management System
        </Typography>

        <Typography
          color="text.secondary"
          mt={1}
        >
          National Health Command Center • Ministry of Health & Family Welfare • Government of India
        </Typography>

        <Typography
          variant="caption"
          display="block"
          mt={1}
        >
          Version 2.0 • Secure • Real-time Monitoring
        </Typography>
      </Paper>

    </MainLayout>
  );
}