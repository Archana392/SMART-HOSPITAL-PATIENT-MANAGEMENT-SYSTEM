import MainLayout from "../../layouts/MainLayout";
import WorkerTable from "../../components/workers/WorkerTable";

import {
  Box,
  Typography,
  Button,
  Paper,
  Chip,
} from "@mui/material";

import AddRoundedIcon from "@mui/icons-material/AddRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import GroupsRoundedIcon from "@mui/icons-material/GroupsRounded";
import HealthAndSafetyRoundedIcon from "@mui/icons-material/HealthAndSafetyRounded";
import VaccinesRoundedIcon from "@mui/icons-material/VaccinesRounded";
import SearchRoundedIcon from "@mui/icons-material/SearchRounded";

import CountUp from "react-countup";

const stats = [
  {
    title: "Registered Workers",
    value: 1250,
    color: "#1565C0",
    icon: <GroupsRoundedIcon sx={{ fontSize: 40 }} />,
  },
  {
    title: "Healthy Workers",
    value: 1184,
    color: "#43A047",
    icon: <HealthAndSafetyRoundedIcon sx={{ fontSize: 40 }} />,
  },
  {
    title: "Vaccinated",
    value: 1025,
    color: "#FB8C00",
    icon: <VaccinesRoundedIcon sx={{ fontSize: 40 }} />,
  },
];

export default function Workers() {
  return (
    <MainLayout>

      {/* HERO */}

      <Paper
        elevation={0}
        sx={{
          p: 5,
          mb: 4,
          borderRadius: 6,
          background:
            "linear-gradient(135deg,#1565C0,#42A5F5)",
          color: "#fff",
        }}
      >
        <Typography
          variant="h3"
          fontWeight={700}
        >
          National Migrant Worker Registry
        </Typography>

        <Typography
          mt={2}
          sx={{
            opacity: .92,
            maxWidth: 700,
            lineHeight: 1.8,
          }}
        >
          Register, monitor and manage migrant workers'
          digital health records across partner hospitals,
          ensuring seamless healthcare access anywhere.
        </Typography>

        <Box
          mt={4}
          display="flex"
          gap={2}
          flexWrap="wrap"
        >
          <Button
            variant="contained"
            startIcon={<AddRoundedIcon />}
            sx={{
              bgcolor: "#fff",
              color: "#1565C0",
              px: 3,
              borderRadius: 3,
              fontWeight: 700,
            }}
          >
            Register Worker
          </Button>

          <Button
            variant="outlined"
            startIcon={<DownloadRoundedIcon />}
            sx={{
              borderColor: "#fff",
              color: "#fff",
              borderRadius: 3,
              px: 3,
            }}
          >
            Export Records
          </Button>
        </Box>
      </Paper>

      {/* STATS */}

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "repeat(3,1fr)",
          },
          gap: 3,
          mb: 4,
        }}
      >
        {stats.map((item) => (
          <Paper
            key={item.title}
            elevation={0}
            sx={{
              p: 3,
              borderRadius: 5,
              boxShadow: "0 12px 30px rgba(0,0,0,.06)",
              transition: ".3s",

              "&:hover": {
                transform: "translateY(-6px)",
              },
            }}
          >
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
            >
              <Box>
                <Typography color="text.secondary">
                  {item.title}
                </Typography>

                <Typography
                  fontSize={34}
                  fontWeight={700}
                  mt={1}
                >
                  <CountUp
                    end={item.value}
                    duration={2}
                    separator=","
                  />
                </Typography>

                <Chip
                  size="small"
                  color="success"
                  label="Updated Today"
                  sx={{ mt: 2 }}
                />
              </Box>

              <Box
                sx={{
                  width: 70,
                  height: 70,
                  borderRadius: "50%",
                  bgcolor: item.color + "20",
                  color: item.color,

                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {item.icon}
              </Box>
            </Box>
          </Paper>
        ))}
      </Box>

      {/* TITLE */}

      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
        flexWrap="wrap"
        gap={2}
      >
        <Box>
          <Typography
            variant="h4"
            fontWeight={700}
          >
            Worker Directory
          </Typography>

          <Typography color="text.secondary">
            Search, filter and manage worker health information.
          </Typography>
        </Box>

        <Button
          variant="contained"
          startIcon={<SearchRoundedIcon />}
          sx={{
            borderRadius: 3,
            px: 3,
          }}
        >
          Advanced Search
        </Button>
      </Box>

      {/* TABLE */}

      <WorkerTable />

    </MainLayout>
  );
}